package com.example.hi_325.splitpay;

import java.util.ArrayList;

/**
 * Created by hi-325 on 24/2/17.
 */

public class Group {
    String id;
    String name;
    ArrayList<Users> member;

}
