package com.example.hi_325.splitpay;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.util.Pair;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;


import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

class MyGroupAdapter extends BaseAdapter{

    private ArrayList<Group> groups;
    private LayoutInflater inflater;
    private Context context;

    public MyGroupAdapter(Context context,ArrayList<Group> groups){
        this.context = context;
        this.groups = groups;
    }

    @Override
    public int getCount() {
        return groups.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.group_view, parent, false);

        TextView group_name = (TextView) rowView.findViewById(R.id.group_name_g);
        TextView oweStatus = (TextView) rowView.findViewById(R.id.group_user);
        TextView oweMoney = (TextView) rowView.findViewById(R.id.group_amount_g);
        ArrayAdapter adapter = new ArrayAdapter(context, R.layout.groupstab);
        //groupActivities.setAdapter(adapter);
        group_name.setText(groups.get(position).name);
        oweStatus.setText("You are owed");
        oweMoney.setText("$"+ groups.get(position).id);
        return rowView;
    }


}


public class GroupsFragment extends Fragment{

    ListView groupListView;
    ArrayList<Group> allGroups;
    MyGroupAdapter groupsAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.groupstab, container, false);
        groupListView =(ListView) rootView.findViewById(R.id.groups_list);
        allGroups = new ArrayList<>();



        groupsAdapter = new MyGroupAdapter(getContext(), allGroups);

        groupListView.setAdapter(groupsAdapter);

        groupsAdapter.notifyDataSetChanged();



        makeRetrofitCalls();
        return rootView;
    }

    private void makeRetrofitCalls() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://ancient-citadel-51174.herokuapp.com/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        MyRetroFit retrofitAPI = retrofit.create(MyRetroFit.class);

        Call<ArrayList<Group>> call = retrofitAPI.retrieveGroups();

        call.enqueue(new Callback<ArrayList<Group>>() {
            @Override
            public void onResponse(Call<ArrayList<Group>> call,
                                   Response<ArrayList<Group>> response) {
                downloadComplete(response.body());
            }

            @Override
            public void onFailure(Call<ArrayList<Group>> call, Throwable t) {


            }
        });
    }

    void downloadComplete(ArrayList<Group> groups) {
        allGroups.clear();
        for (Group aGroup: groups){
            allGroups.add(aGroup);
        }

        groupsAdapter.notifyDataSetChanged();
    }
}