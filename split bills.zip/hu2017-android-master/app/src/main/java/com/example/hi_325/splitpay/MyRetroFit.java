package com.example.hi_325.splitpay;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface MyRetroFit {

    @GET("users/?format=json")
    Call<ArrayList<Users>> retrieveUsers();

    @GET("groups/?format=json")
    Call<ArrayList<Group>> retrieveGroups();

    @GET("bills/?format=json")
    Call<ArrayList<Bills>> retrieveBills();

}

