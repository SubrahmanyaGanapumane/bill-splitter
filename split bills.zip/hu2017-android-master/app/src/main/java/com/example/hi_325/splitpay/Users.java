package com.example.hi_325.splitpay;

/**
 * Created by hi-325 on 24/2/17.
 */

public class Users {
    String id;
    String username;
    String email;


}
