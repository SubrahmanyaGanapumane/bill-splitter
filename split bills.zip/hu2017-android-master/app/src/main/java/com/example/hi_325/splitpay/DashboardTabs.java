package com.example.hi_325.splitpay;

/**
 * Created by hi-325 on 23/2/17.adapter
 */

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.view.View;

import java.util.List;

public class DashboardTabs extends FragmentStatePagerAdapter {
    List<String> tabHeader;

    public DashboardTabs(FragmentManager fm, List<String> tabHeader) {
        super(fm);
        this.tabHeader = tabHeader;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                FriendsFragment tab1 = new FriendsFragment();
                return tab1;
            case 1:
                GroupsFragment tab2 = new GroupsFragment();
                return tab2;

            case 2:
                BillsFragment tab3 = new BillsFragment();
                return tab3;

            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return tabHeader.size();
    }

    @Override
    public Object instantiateItem(View container, int position) {
        return super.instantiateItem(container, position);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return tabHeader.get(position);
    }
}