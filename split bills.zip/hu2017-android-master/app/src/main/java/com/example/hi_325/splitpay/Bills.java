package com.example.hi_325.splitpay;

/**
 * Created by hi-325 on 24/2/17.
 */

import java.util.ArrayList;


public class Bills {
    public int id;
    public String name;
    public Users paid_by;
    public ArrayList<Users> split_between;
    public Group group;
    public int amount;
}