package com.example.hi_325.splitpay;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

class MyActivityAdapter extends BaseAdapter{

    private ArrayList<Bills> bills;
    private LayoutInflater inflater;
    private Context context;

    public MyActivityAdapter(Context context, ArrayList<Bills> bills){
        this.context = context;
        this.bills = bills;
    }

    @Override
    public int getCount() {
        return bills.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.activity, parent, false);
        TextView groupName = (TextView) rowView.findViewById(R.id.textView5);
        TextView moneyOwe = (TextView) rowView.findViewById(R.id.textView6);
        TextView  person1= (TextView) rowView.findViewById(R.id.textView7);

        groupName.setText(bills.get(position).group.name);
        person1.setText(bills.get(position).paid_by.username+" added bill");
        moneyOwe.setText("$"+ bills.get(position).amount);
        return rowView;
    }
}
public class BillsFragment extends Fragment {

    ListView activitylistview;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activitiestab, container, false);
        activitylistview = (ListView) rootView.findViewById(R.id.activities_list_view);
        callRetrofit();
        return rootView;
    }

    private void callRetrofit() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://ancient-citadel-51174.herokuapp.com/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        MyRetroFit retrofitAPI = retrofit.create(MyRetroFit.class);
        Call<ArrayList<Bills>> call = retrofitAPI.retrieveBills();
        call.enqueue(new Callback<ArrayList<Bills>>() {
            @Override
            public void onResponse(Call<ArrayList<Bills>> call,
                                   Response<ArrayList<Bills>> response) {
                callAdapterSetter(response.body());
            }

            @Override
            public void onFailure(Call<ArrayList<Bills>> call, Throwable t) {

            }
        });

        }


    void callAdapterSetter(ArrayList<Bills> bills) {
        MyActivityAdapter adapter = new MyActivityAdapter(getContext(),bills);
        activitylistview.setAdapter(adapter);

    }
}